package com.bank.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;*/




@Entity
@Table(name="passbook_p")
public class Passbook implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionId;
	
	private String TransactionDetails;
	
	@ManyToOne
	@JoinColumn(name="Customer")
	private Customer customer;
	
	public Passbook() {
		
	}
public Passbook(int transactionId,

String TransactionDetails,Customer customer) {
	this.transactionId=transactionId;

	this.TransactionDetails=TransactionDetails;
	this.customer=customer;

}
		
	
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDetails() {
		return TransactionDetails;
	}
	public void setTransactionDetails(String transactionDetails) {
		TransactionDetails = transactionDetails;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Passbook(Integer transactionId,
			String transactionDetails,Customer customer) {
		super();
		this.transactionId = transactionId;

		this.TransactionDetails = transactionDetails;
	 this.customer=customer;
	}
	
	
}
