package com.bank.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;




@Entity
@Table(name="customer_p")
public class Customer implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	private int accNumber;
	@Column(length=30,nullable=false)
	private String name;
	private String emailId;
	private String address;
	private String mobileno;
	private String panno;
	private	Integer age;

	private	int pin;
	private double currBal=0.0;

	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch=FetchType.EAGER)	
	private List<Passbook> transactions = new ArrayList<Passbook>();
	public Customer()
	{

	}
public Customer(String name, String emailId, 
			String address, String mobileno, String panno, int age,
			int accNumber, int pin, double currBal) {
		super();
		this.name = name;
		this.emailId = emailId;
		
		this.address = address;
		this.mobileno = mobileno;
		this.panno = panno;
		this.age = age;
		this.accNumber = accNumber;
		this.pin = pin;
		this.currBal = currBal;
	}


	public List<Passbook> getTransactions() {
	return transactions;
}
public void setTransactions(List<Passbook> transactions) {
	this.transactions = transactions;
}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}




	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getMobileno() {
		return mobileno;
	}


	public int getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}


	public int getPin() {
		return pin;
	}


	public void setPin(int pin) {
		this.pin = pin;
	}


	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	public String getPanno() {
		return panno;
	}


	public void setPanno(String panno) {
		this.panno = panno;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public double getCurrBal() {
		return currBal;
	}


	public void setCurrBal(double currBal) {
		this.currBal = currBal;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", emailId=" + emailId + ", address="
				+ address + ", mobileno=" + mobileno + ", panno=" + panno
				+ ", age=" + age + ", accNumber=" + accNumber + ", pin=" + pin
				+ ", currBal=" + currBal + "]";
	}

	public void addTransaction(Passbook transaction) {
		transaction.setCustomer(this);			//this will avoid nested cascade
		this.getTransactions().add(transaction);
	}
	


}

