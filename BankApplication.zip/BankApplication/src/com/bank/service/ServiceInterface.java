package com.bank.service;

import java.util.List;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFound;

public interface ServiceInterface {
public boolean  addCustomer(Customer c) throws CustomerNotFound;
//public int withDraw(Customer c,int withdraw);
//public  void updateCustomer(Customer c,int amount) throws CustomerNotFound;
public  Customer getCustomerDetails(int accNumber2,String email,int pin)throws CustomerNotFound;

//public boolean validAccountNo(String email,int accNumber,int pin);
public boolean validateAmount(Double withdraw);
//public boolean validateDepositAmount(Double amount);
//public boolean validatedeposit(int deposit);
//public int showBalance(Customer c,int accNumber1);
//public boolean printTransaction(int accNumber4)throws CustomerNotFound;

//public boolean verifyAcc(String email4, int accNumber4);
 //public Customer displayCust(int accNumber);
 // public boolean fundTransfer( String email3, int accNumber3, int pin3,Customer a,Customer b, String email4,int accNumber4,int amount);
  public boolean validateName(String name);
  public boolean   deposit(int accNumber2,Double deposit) throws CustomerNotFound;
  public boolean validateAge(int age);
  public boolean validatePhno(String mobileno);
  public boolean validatePan(String panno);
  public boolean validateMail(String email);
  public boolean   withdraw(int accNumber, Double withdraw) throws CustomerNotFound;
  public boolean verifyDetails(String email1, int accNumber1, int pin1)throws CustomerNotFound;
  public Double showBalance(int accNumber1)throws CustomerNotFound;
 public boolean  verifyAccno(int accNumber4,String email4)throws CustomerNotFound;
 public  boolean fundTransfer(int accNumber3, int accNumber4,Double amount)throws CustomerNotFound;
 public List<Passbook> printTransaction(int accountNumber) throws CustomerNotFound;
}
